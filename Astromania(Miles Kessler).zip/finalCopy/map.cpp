#include <iostream>
#include <stdio.h>
#include <time.h>
#include <vector>
#include <ncurses.h>
#include "map.h"
#include "mapPiece.h"
#include "player.h"
#include "enemy.h"
#include "asteroidSubClass.h"
#include "NPCSubClass.h"
#include "barSubClass.h"
#include "nebulaSubClass.h"
#include "dialogue.h"
#include "battle.h"
#define BATTLE_UNRESOLVED 0
#define BATTLE_WON 1
#define BATTLE_LOST 2
using namespace std;
Map::Map(int level) {
    inGameTime = STARTTIME;
    int pieceSpot[2];
    levelType = level;
    mapPiece bar;
    mapPiece bar2;
    mapPiece bar3;
    mapPiece bar4;
    // mapPiece nebula1;
    // mapPiece nebula2;
    // mapPiece nebula3;
    // mapPiece nebula4;
    // mapPiece nebula5;
    int offsetX, offsetY;
    ifstream levelTxt;
    string line = "";
    levelTxt.open("dialogue/levelTitle.txt");
    while(!levelTxt.eof()) {
        getline(levelTxt, line);
        levelTitles.push_back(line);
    }
    levelTxt.close();
    switch (level) {
        case LEVEL_ASTEROID:
            sideLength = 8;
            for (int k = 0; k < NUM_ASTEROIDS; k++) {
                if (findEmptyMapPosition(pieceSpot)) {
                    mapPiece asteroid = mapPiece(ASTEROID, pieceSpot[0], pieceSpot[1], -1);
                    mapPieces.push_back(asteroid);
                }
            }
        break;
        case LEVEL_ENEMY:
            sideLength = 9;
            for (int i = 0; i < NUM_ENEMIES; i++) {
                if (findEmptyMapPosition(pieceSpot)) {
                    mapPiece enemy = mapPiece(ENEMY, pieceSpot[0], pieceSpot[1], 4);
                    mapPieces.push_back(enemy);
                }
            }  
            // add some healthpacks and energy packs so you can fight enemies
            for (int i = 0; i < NUM_HEALTH_PACKS; i++) {
                if (findEmptyMapPosition(pieceSpot)) {
                    mapPiece healthPack = mapPiece(HEALTH_PACK, pieceSpot[0], pieceSpot[1], -1);
                    mapPieces.push_back(healthPack);
                }
            }
            for (int j = 0; j < NUM_ENERGY_PACKS; j++) {
                if (findEmptyMapPosition(pieceSpot)) {
                    mapPiece energyPack = mapPiece(ENERGY_PACK, pieceSpot[0], pieceSpot[1], -1);
                    mapPieces.push_back(energyPack);
                }
            }
        break;
        case LEVEL_BAR:
            sideLength = 10;
            // Put the bar in place before all other mapPieces
            offsetX = 8;
            offsetY = 6;
            bar = mapPiece(BAR, (offsetX), (offsetY), 3);
            mapPieces.push_back(bar);
            bar2 = mapPiece(BAR, (offsetX+1), (offsetY), 3);
            mapPieces.push_back(bar2);
            bar3 = mapPiece(BAR, (offsetX), (offsetY+1), 3);
            mapPieces.push_back(bar3);
            bar4 = mapPiece(BAR, (offsetX+1), (offsetY+1), 3);
            mapPieces.push_back(bar4);
            for (int i = 0; i < NUM_NPCS; i++) {
                if (findEmptyMapPosition(pieceSpot)) {
                        mapPiece npc = mapPiece(NPC, pieceSpot[0], pieceSpot[1], i);
                        mapPieces.push_back(npc);
                }
            }
        break;
        case LEVEL_NEBULA:
            sideLength = 12;
            for (int k = 0; k < NUM_ASTEROIDS; k++) {
                if (findEmptyMapPosition(pieceSpot)) {
                    mapPiece asteroid = mapPiece(ASTEROID, pieceSpot[0], pieceSpot[1], -1);
                    mapPieces.push_back(asteroid);
                }
            }
            for (int k = 0; k < NUM_NEBULAPIECES; k++) {
                if (findEmptyMapPosition(pieceSpot)) {
                    mapPiece nebula = mapPiece(NEBULA, pieceSpot[0], pieceSpot[1], -1);
                    mapPieces.push_back(nebula);
                }
            }
            // offsetX = (rand() % sideLength) - 1;
            // offsetY = (rand() % sideLength) - 1;
            // nebula1 = mapPiece(NEBULA, (offsetX), (offsetY), -1);
            // mapPieces.push_back(nebula1);
            // nebula2 = mapPiece(NEBULA, (offsetX-1), (offsetY), -1);
            // mapPieces.push_back(nebula2);
            // nebula3 = mapPiece(NEBULA, (offsetX), (offsetY+1), -1);
            // mapPieces.push_back(nebula3);
            // nebula4 = mapPiece(NEBULA, (offsetX+1), (offsetY), -1);
            // mapPieces.push_back(nebula4);
            // nebula5 = mapPiece(NEBULA, (offsetX), (offsetY -1), -1);
            // mapPieces.push_back(nebula5);
        break;
    }
   
    // Set up the player map piece last, on any available spot
    if (findEmptyMapPosition(pieceSpot)) {
        mapPiece playerMapPiece = mapPiece(PLAYER, pieceSpot[0], pieceSpot[1], -1);
        mapPieces.push_back(playerMapPiece);
    }
    wonAsteroids = false;
    deadEnemies = 0;
    //barChoice = -1;
    outcomeApplied = false;
    leaveBar = false;
    Enemy enemy = Enemy();
    Player player = Player();
    Dialog dialog = Dialog();
    Battle battle = Battle();
}
Player Map::getPlayerStats() {
    return player;
}
void Map::converse(vector<mapPiece>mapPieces, char userKey) {
    // if within a square above, below, left of, or right of the enemy, start a conversation
    int npcId = -1; 
    vector<int>playerXY = mapPieces[mapPieces.size() -1].getPosition();
    for (int i = 0; i < mapPieces.size() - 1; i++ ) {
        vector<int>npcXY = mapPieces[i].getPosition();
        if ( ((abs(playerXY[0] - npcXY[0]) < 2) && (playerXY[1] == npcXY[1])) ||
            ((abs(playerXY[1] - npcXY[1]) < 2) && (playerXY[0] == npcXY[0])) ) {
                if (mapPieces[i].getPieceType() == NPC || mapPieces[i].getPieceType() == BAR) {
                    npcId = mapPieces[i].getConversationId();
                    break;
                }   
        }
    }// idea for player choice-progress to different levels based on what NPC you talk to
    // if (npcId == 0) {
    //     barChoice = 0;
    // }
    // else if (npcId == 1) {
    //     barChoice = 2;
    // }
    if (npcId > -1) { 
            // just prevent enemy moving while conversation going on
        if (dialog.canDialogStart()) {
            dialog.start(npcId);
        } else if (!dialog.completed()) {
            dialog.interact(userKey);
            
        }
        dialog.render();
    } else {
        dialog.end();
        move(5,0);
        clrtoeol();
    }
    
}
void Map::fight(vector<mapPiece>mapPieces, char userKey) {
    // if within a square above, below, left of, or right of the enemy, start a conversation
    int enemyId = -1; 
    int interactOutcome = 0;
    int enemyCounter = 0;
    vector<int>playerXY = mapPieces[mapPieces.size() -1].getPosition();
    for (int i = 0; i < mapPieces.size() - 1; i++ ) {
        vector<int>enemyXY = mapPieces[i].getPosition();
        if (mapPieces[i].getPieceType() == ENEMY) {
            if ( ((abs(playerXY[0] - enemyXY[0]) < 2) && (playerXY[1] == enemyXY[1])) ||
                ((abs(playerXY[1] - enemyXY[1]) < 2) && (playerXY[0] == enemyXY[0])) ) {
                    enemyId = enemyCounter;
                    break;
            }
            enemyCounter++;
        }
    }
    if (enemyId > -1) { 
            // just prevent enemy moving while conversation going on
        if (battle.canBattleStart() && enemy[enemyId].getHealth() > 0) {
            battle.start(enemyId);
            outcomeApplied = false;
        } 
        battle.interact(userKey, player, enemy[enemyId]);
        battle.render();
        if (battle.completed() && !outcomeApplied) {
            double userDamage = player.getWeaponStats().getDamage();
            double enemyDamage = enemy[enemyId].getWeapon().getDamage();
            double userEnergy = player.getEnergy();
            double enemyEnergy = enemy[enemyId].getEnergy();
            switch(battle.getEndId()) {
                case 0:
                    player.setHealth(0);
                    break;
                case 1:
                    if (userKey == '1') {
                        enemy[enemyId].updateHealth(-USER_FIST_DAMAGE);
                        enemy[enemyId].updateEnergy(-USER_FIST_DAMAGE);
                    } else {
                        enemy[enemyId].updateHealth(-userDamage);
                        enemy[enemyId].updateEnergy(-userDamage);
                    }
                    if (enemy[enemyId].getHealth() <= 0) {
                        deadEnemies++;
                        //cout << "more dead enemies" << endl;
                    }
                    break;
                case 2:
                    player.addHealth(-enemyDamage);
                    player.addEnergy(-enemyDamage);
                    break;
                case 3:
                    break;
            }
            outcomeApplied = true;
        }
    } else {
        battle.end();
        move(5,0);
        clrtoeol();
    }
    
}

// if player next to an energy or health, "eat them"
void Map::consume() {	
    vector<int>playerXY = mapPieces[mapPieces.size() - 1].getPosition();	
    for (int i = 0; i < mapPieces.size() - 1; i++ ) {	
        vector<int>healthPiece = mapPieces[i].getPosition();	
        if ( ((abs(playerXY[0] - healthPiece[0]) < 2) && (playerXY[1] == healthPiece[1])) ||	
             ((abs(playerXY[1] - healthPiece[1]) < 2) && (playerXY[0] == healthPiece[0])) ) {	
                int mapPieceType = mapPieces[i].getPieceType();	
                //cout << "check health:" << mapPieceType << endl;	
                if (mapPieceType == HEALTH_PACK) {	
                  if (mapPieces[i].getHealthPackAmount() > 0) {	
                    player.addHealth(HEALTH_PACK_TRANSFER_SPEED);	
                    mapPieces[i].depleteHealth(HEALTH_PACK_TRANSFER_SPEED);	
                  }	
                 } else if (mapPieceType == ENERGY_PACK) {	
                  if (mapPieces[i].getEnergyPackAmount() > 0) {	
                    player.addEnergy(ENERGY_PACK_TRANSFER_SPEED);	
                    mapPieces[i].depleteEnergy(ENERGY_PACK_TRANSFER_SPEED);	
                  }	
                }	
        }	
    }	
}
bool Map::updateMap() {
   char userKey = player.getUserKey();
    if (userKey == 27) {
        return false;
    }
   if (levelType == LEVEL_ENEMY) {
        int enemyCount = 0;
        for (int i = 0; i < mapPieces.size() -1; i++) {
            vector<int> currentPosition = mapPieces[i].getPosition();
            vector<bool> availablePositions = findAvailableMapPositions(currentPosition);
            if (mapPieces[i].getPieceType() == ENEMY) {
                if (!battle.inProgress() && !dialog.inProgress() && enemy[enemyCount].getHealth() > 0) {
                    mapPieces[enemyCount].randomMove(availablePositions, sideLength);
                }
            enemyCount++;
            }  
            if (mapPieces[i].getPieceType() == NEBULA) {
                //int nebulaCount = 0;
                mapPieces[i].randomMove(availablePositions, sideLength);
                //nebulaCount++;
            }
        }
   } else if (levelType == LEVEL_ASTEROID) {
        wonAsteroids = false;
        vector<int>playerXY = mapPieces[mapPieces.size() - 1].getPosition();
        for (int i = 0; i < mapPieces.size() -1; i++) {
            vector<int> asteroidPos = mapPieces[i].getPosition();	
            if (mapPieces[i].getPieceType() == ASTEROID) {
                if ( ((abs(playerXY[0] - asteroidPos[0]) < 2) && (playerXY[1] == asteroidPos[1])) ||	
                ((abs(playerXY[1] - asteroidPos[1]) < 2) && (playerXY[0] == asteroidPos[0])) ) {
                    player.addHealth(-10);
                }
            }
        } 
   } else if (levelType == LEVEL_NEBULA) {
    wonNebula = false;
        vector<int>playerXY = mapPieces[mapPieces.size() - 1].getPosition();
        for (int i = 0; i < mapPieces.size() -1; i++) {
            vector<int> nebulaPos = mapPieces[i].getPosition();	
            if (mapPieces[i].getPieceType() == ASTEROID || mapPieces[i].getPieceType() == NEBULA) {
                if ( ((abs(playerXY[0] - nebulaPos[0]) < 2) && (playerXY[1] == nebulaPos[1])) ||	
                ((abs(playerXY[1] - nebulaPos[1]) < 2) && (playerXY[0] == nebulaPos[0])) ) {
                    player.addHealth(-10);
                }
            }
        } 
   }
   
   mapPiece userPiece = mapPieces[mapPieces.size() - 1];
   vector<int>playerCoords = userPiece.getPosition();
   vector<bool>availableMoves = findAvailableMapPositions(playerCoords);
   int moveOffset[2] = {0,0};
    if (!player.movementControl( playerCoords, userKey, moveOffset, availableMoves)) {
        return false;
    }
    // if player didn't quit or dialogue progressing, move the player
    mapPieces[mapPieces.size() - 1].move(moveOffset[0], moveOffset[1], sideLength);
    vector<int>newPlayerCoords = userPiece.getPosition();
    mvprintw(5, 15, to_string(newPlayerCoords[0]).c_str());
    if (levelType == LEVEL_ENEMY) {
        fight(mapPieces, userKey);
        consume();
    } else if (levelType == LEVEL_ASTEROID) {
        if (newPlayerCoords[0] == sideLength - 1) {
            wonAsteroids = true;
        }
    } else if (levelType == LEVEL_NEBULA){
        if (newPlayerCoords[0] == sideLength - 1) {
            wonNebula = true;
        }
    } else {
        if (newPlayerCoords[1] == sideLength -1) {
            leaveBar = true;
        } 
        converse(mapPieces, userKey);
    }
    return true;
}

int Map::drawMap() {
    if (!updateMap()){
        return 1; 
    }
    if (player.getHealth() <= 0) {
        return 2;
    }
    if (wonAsteroids == true || deadEnemies >= 4 || leaveBar == true) {
        return 3;
    }
    if (wonNebula == true) {
        return 4;
    }
    // if (barChoice == 0) {
    //     return 4;
    // }
    // if (barChoice == 1) {
    //     return 5;
    // }
    for (int y = 0; y < sideLength; y++) {
        for (int x = 0; x < sideLength; x++) {
            mvprintw(x,y, ".");
        }
    }
    string rolePlayerName = player.getUsername();
    double rolePlayerHealth = player.getHealth();
    double rolePlayerEnergy = player.getEnergy();
    double rolePlayerScore = player.getScore();
    string rolePlayerWeapon = player.getWeaponStats().getWeaponName();
    showGameStatus(rolePlayerName, rolePlayerHealth, rolePlayerEnergy, rolePlayerWeapon, rolePlayerScore);
    inGameTime += 0.1;  
        // imagine you have received an array of enemies
    // loop over that array, and for each enemy, ask it for its position and render character
    // then mvprintw(posX, posY, character) to put that enemy on the map
    for (int i = 0; i < mapPieces.size(); ++i) {
        vector <int> piecePos = mapPieces[i].getPosition();
        string pieceChar = mapPieces[i].getDisplayCharacter();
        int pieceType = mapPieces[i].getPieceType();	
        if ((pieceType == ENERGY_PACK) || (pieceType == HEALTH_PACK)) {	
           int energyAvailable = mapPieces[i].getEnergyPackAmount();	
           int healthAvailable = mapPieces[i].getHealthPackAmount();	
           if (pieceType == ENERGY_PACK) {	
             if (energyAvailable <= 0) {	
               pieceChar = "0"; // out of energy to give to the player, so put a "0" on the map where the energy pack is	
             }	
           } else {	
            if (healthAvailable <= 0) {	
                pieceChar = "0"; // out of energy to give to the player, so put a "0" on the map where the energy pack is	
            }	
           }	
        }
        if (pieceType == ENEMY) {
            if (enemy[i].getHealth() <= 0) {
                pieceChar = "X";
            } 
            mvprintw(piecePos[0], piecePos[1], pieceChar.c_str());
        } else {
            mvprintw(piecePos[0], piecePos[1], pieceChar.c_str());
        }
       
    }
    //vector<int>playerPosition = user.getPosition();
    //cout << playerPosition[0] << endl;
    //char playerChar = user.getDisplayCharacter();
    //mvprintw(playerPosition[0], playerPosition[1], "P");
    refresh();
    return 0;
}
void Map::setupCurses() {
    initscr();
    cbreak();
    halfdelay(2);

    noecho();
    curs_set(0);
    start_color();
    init_pair(1, COLOR_YELLOW, COLOR_RED);
}
void Map::shutdownCurses() {
    endwin();
}

int Map::getSidelength() {
    return sideLength;
}
// vector<mapPiece> Map::getMapPieces() {
//     return mapPieces;
// 
void Map::showGameStatus(string userName,double health, double energy, string weapon, double score) {
  string labels[6] = {"Name", "Health", "Energy", "Weapon", "Score", "Play Time"} ;
  string fullLabel = "";
  fullLabel.append(labels[0]);
  fullLabel.append(": ");
  fullLabel.append(userName);
  fullLabel.append("    ");
  fullLabel.append(labels[1]);
  fullLabel.append(": ");
  string trimmedHealth = to_string(health).substr(0, to_string(health).find(".") + 2);
  fullLabel.append(trimmedHealth);
  fullLabel.append("    ");
  fullLabel.append(labels[2]);
  fullLabel.append(": ");
  string trimmedEnergy = to_string(energy).substr(0, to_string(energy).find(".") + 2);
  fullLabel.append(trimmedEnergy);
  fullLabel.append("    ");
  fullLabel.append(labels[3]);
  fullLabel.append(": ");
  fullLabel.append(weapon);
  fullLabel.append("    ");
  fullLabel.append(labels[4]);
  fullLabel.append(": ");
  string trimmedScore = to_string(score).substr(0, to_string(score).find(".") + 2);
  fullLabel.append(trimmedScore);
  fullLabel.append("    ");
  fullLabel.append(labels[5]);
  fullLabel.append(": ");
  string trimmedTime = to_string(inGameTime).substr(0, to_string(inGameTime).find(".") + 2); // just want first decimal place
  fullLabel.append(trimmedTime);
  fullLabel.append(" seconds");
  move(sideLength + 1,3);
  clrtoeol();
  mvprintw(sideLength + 2 ,3,  fullLabel.c_str());
  mvprintw(sideLength + 3 ,3, "WASD to move, ESC or Q to quit");
  move(0, sideLength);
  clrtoeol();
  mvprintw(0, sideLength + 5, levelTitles[levelType - 1].c_str());
}

// find an available spot next to a position on the map
vector<bool> Map::findAvailableMapPositions(vector<int> currentPosition) {
    vector<bool> availables;
    for (int i = 0; i < 4; ++i) {
        availables.push_back(true); // initially, assume all four directions are not occupied
    }
    // now look in all directions. if any mapPiece is in the square in that direction,
    // mark that available as false;
    int directionsCheck[4][2] = 
    {{0,-1}, {1,0}, {0,1}, {-1,0}};
    for (int j = 0; j < 4; ++j) {
        int checkPosX = currentPosition[0] + directionsCheck[j][0];
        int checkPosY = currentPosition[1] + directionsCheck[j][1];
        for(int i = 0; i < mapPieces.size(); i++) {
            vector<int>piecePos = mapPieces[i].getPosition();

            if (piecePos[0] == checkPosX && piecePos[1] == checkPosY) {
                availables[j] = false; // square already occupied
            }
        }
    }
    return availables;
}

// find an available spot on the map not occupied by any mapPiece. Return
// an available spot in the provided int array, and true, if we were able to find a spot.
// otherwise return false
bool Map::findEmptyMapPosition(int openSpot[]) {
    int attempts = 0;
    int posX, posY;
    bool inUse = false;
    while (attempts < 10000) {  // try 10000 times to find an open spot, then give up!
        posX = rand() % sideLength;
        posY = rand() % sideLength;
        inUse = false;
        for (int i = 0; i < mapPieces.size(); i++) {
            vector<int> usedPosition = mapPieces[i].getPosition();
            if ((usedPosition[0] == posX) && (usedPosition[1] == posY)) {
                inUse = true;
                break;
            }
       }
       if (!inUse) {
            openSpot[0] = posX;
            openSpot[1] = posY;
            return true;
       }
       attempts++;
    }
    return false; // we couldn't find any random spot to place a piece!
}