#include <iostream>
#include <fstream>
#include <cstdlib> 
#include <vector>
#include <ncurses.h>
#include "mapPiece.h"
#ifndef NEBULA_H
#define NEBUlA_H
#define NUM_NEBULAPIECES 10

class Nebula: public mapPiece {
    public:
        Nebula(int posX, int posY) : mapPiece(ENEMY, posX, posY, 3) { 
        }
        

};
#endif