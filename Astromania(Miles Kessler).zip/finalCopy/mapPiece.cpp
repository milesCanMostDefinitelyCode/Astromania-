#include <iostream>
#include <vector>
#include <ncurses.h>
#include "map.h"
#include "mapPiece.h"
mapPiece::mapPiece() {
    
}
mapPiece::mapPiece(int type, int posX, int posY, int conversationId)  {
    position.push_back(posX);
    position.push_back(posY);
    pieceType = type;
    healthPackAmount = 100;
    energyPackAmount = 100;
    conversationID = conversationId;
    displayCharacters[PLAYER] = "P";
    displayCharacters[NPC] = "N";
    displayCharacters[ENEMY] = "E";
    displayCharacters[BAR] ="B";
    displayCharacters[ASTEROID] = "*";
    displayCharacters[NEBULA] = "@";
    displayCharacters[HEALTH_PACK] = "+";
    displayCharacters[ENERGY_PACK] = "!";

}
string mapPiece::getDisplayCharacter() {
    return displayCharacters[pieceType];
}
int mapPiece::getConversationId() {
    return conversationID;
}
vector<int> mapPiece::getPosition() {
    vector<int>posChange;
    posChange.push_back(position[0]);
    posChange.push_back(position[1]);
    return posChange;
}
bool mapPiece::setPosition(int posX, int posY) {
    //cout << "setting " << position[0] << " " << position[1] << " " << posX << " " << posY << endl;
    position[0] = posX;
    position[1] = posY;
    return true;
}
void mapPiece::move(int deltaX, int deltaY, int mapWidth) {
   
    vector <int> currentPosition = getPosition();
    //vector<mapPiece>mapPortions = levelMap.getMapPieces();
   vector<int>newPos;
   newPos.push_back(max(0, min(currentPosition[0]+ deltaX, mapWidth - 1)));
   newPos.push_back(max(0, min(currentPosition[1]+ deltaY, mapWidth - 1)));
   
   setPosition(newPos[0], newPos[1]);

   vector<int> newPos1 = getPosition();
   //cout << currentPosition[1] << ":" << newPos1[1] << endl;
   
}

int mapPiece::getPieceType() {
    return pieceType;
}

int mapPiece::getHealthPackAmount() {
    return healthPackAmount;
}

int mapPiece::getEnergyPackAmount() {
    return energyPackAmount;
}

void mapPiece::depleteEnergy(int depleteAmount) {
    energyPackAmount = max(0, energyPackAmount - depleteAmount);
}

void mapPiece::depleteHealth(int depleteAmount) {
    int newHealthPackAmount = healthPackAmount - depleteAmount;
    healthPackAmount = max(0, newHealthPackAmount);
}

void mapPiece::randomMove(vector<bool>availablePositions, int mapWidth) {
   int directions[4][2] = 
    {{0,-1}, {1,0}, {0,1}, {-1,0}};
   int moveIndex = rand() % 4;
   if (availablePositions[moveIndex] == true) {
      int deltaX = directions[moveIndex][0];
      int deltaY = directions[moveIndex][1];
      move(deltaX, deltaY, mapWidth);
   }
}