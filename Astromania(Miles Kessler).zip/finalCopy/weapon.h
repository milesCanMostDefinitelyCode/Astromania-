#include <iostream>
#ifndef WEAPON_H
#define WEAPON_H
#define BASICDAM 10
#define BASICSTRENGTH 40
#define BASICREACH 2
#define MELEEDAM 40
#define MELEESTRENGTH 90
#define MELEEREACH 1
#define PISTOLDAM 10
#define PISTOLSTRENGTH 40
#define PISTOLREACH 2
#define LONGGUNDAM 45
#define LONGGUNSTRENGTH 70
#define LONGGUNREACH 5
using namespace std;
class Weapon {
    private:
        double damage;
        double strength;
        double reach;
        string weaponName;
        string weaponType;
    public:
        //creates default pistol weapon
        Weapon();
        //creates default Weapon with user-chosen type
        Weapon(int type);
        //creates custom user-chosen Weapon
        Weapon(double newDamage, double newStrength, double newReach, string newName, string newType);
        double getDamage();
        double getStrength();
        double getReach();
        string getWeaponType();
        string getWeaponName();
        void setDamage(double newDamage);
        void setStrength(double newStrength);
        void setReach(double newReach);
        void setWeaponType(string diffType);
        void setWeaponName(string newWeaponName);
};
#endif