#include <iostream>
#include <string>
#include <vector>
#ifndef DIALOG_H
#define DIALOG_H
#define SILENCE 0 // no dialog happening
#define GREETING 1
#define DECISION 2

#define ASCII_KEY_1 49
#define ASCII_KEY_2 50
#define ASCII_KEY_3 51
#define LEFT_OF_DIALOG_AREA 20
#define TOP_OF_DIALOG_AREA 2
#define DIALOG_DECISION_DISPLAY_TIME 30 // 3 seconds (each loop is 1/10th of a second) for decision display to clear

using namespace std;
class Dialog  {
 private:
    int conversationId;
    int outcomeId;
    int state;
    int decisionTime;
    vector<string> greetings;
    vector<string> decisions[4];   // up to 3 decisions for every prompt
    vector<string> outcomeSets[4]; // up to 3 outcomes for every decision, for now
    string quoteDialogLine(string dialogLine);
 public:
    Dialog();
    void start(int enemyID);
    void end();
    void decide(int outcomeId);
    void setState(int newState);
    void select(int whichConversation);
    bool canDialogStart();
    bool inProgress();
    bool completed();
    int  interact(int userChar);
    void render();
    void erase();
};
#endif