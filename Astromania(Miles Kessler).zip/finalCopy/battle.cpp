#include <iostream>
#include <fstream>
#include "enemy.h"
#include "weapon.h"
#include "battle.h"
#include <ncurses.h>
#include <vector>
using namespace std;
//1 interaction
//greeting:
//enemy attack! Fight back with:
//answer
//1. Main Weapon
//2. Fist
//interact passes in player and enemy object to the combat function
//combat function decides whether player is dead, enemy is dead, player hurt enemy, or enemy hurt player
//returns int based on function decision
//int determines outcome
Battle::Battle() {

  state = SILENCE;        // initially, no interaction going on
  fightingId = -1;    // initially, no conversation selected
  outcomeId = -1;         // once in a conversation, user sees some kind of outcome from a choice
  endId = -1;
  decisionTime = 0;       // how much time to display the results of a decision before dialog is cleared for a new conversation
  combatOver = false;

  // Set up some interactions. You will read these from your files instead.

  // First conversation
    string line = "";
    attackString = "Enemy attack!";
    fightBackString = "Fight back with 1. Main weapon 2. Fist";
    ifstream fightBackOutcomes;
    fightBackOutcomes.open("dialogue/battleOutcomes.txt");
    combatOutcomeSets.clear();
    while (!fightBackOutcomes.eof()) {
        getline(fightBackOutcomes, line);
        //cout << line << endl;
        combatOutcomeSets.push_back(line);
    }
    fightBackOutcomes.close();

  
}

// Code begins here


void Battle::erase() {
  for (int i = 0; i < 5; ++i) {
    move(TOP_OF_DIALOG_AREA + i, LEFT_OF_DIALOG_AREA);
    clrtoeol();
  }
}

void Battle::setState(int newState) {
  state = newState;
}

void Battle::select(int whichConversation) {
  fightingId = whichConversation;
}

bool Battle::canBattleStart() {
  return (state == SILENCE);
}

bool Battle::inProgress() {
  return (state == GREETING || state == DECISION);
}

bool Battle::completed() {
  return (state == DECISION);
}
// int Battle::fightCheck(Player playerStats, roadGang enemyStats) {

// }
void Battle::start(int enemyID) {
  int newConversation = enemyID;
  select(newConversation); // select a random conversation
  setState(GREETING);      // change state to conversation is now in flight
}

void Battle::end() {
  setState(SILENCE);
  erase();
  combatOver = false;
}

string Battle::quoteBattleLine (string BattleLine) {
  string quotedString = "";
  quotedString.append(BattleLine);
  return (quotedString);
}

void Battle::decide(int newOutcomeId) {
  setState(DECISION);
  outcomeId = newOutcomeId;
  decisionTime = DIALOG_DECISION_DISPLAY_TIME;
  //cout << "decide()" << state << endl;
}

int Battle::interact(int userChar, Player user, Enemy gangMember) {
  int combatOutcome = 0;
  switch (state) {
  case SILENCE:
    // do nothing, no conversation happening
    break;
  case GREETING:
    // Greeting mode; interpret the user's choice for a decision, and set the outcome if a choice was provided by the user.
    switch (userChar) {
    case ASCII_KEY_1:
      decide(USER_DECISION_WEAPON);
      break;
    case ASCII_KEY_2:
      decide(USER_DECISION_FIST);
      break;
    }
    break;
  case DECISION:
    // User made a decision. Possibly, do some other game logic here..
    endId = combat(user, gangMember);
    break;
  }
  

  return 0;
}

int Battle::getEndId() {
  return endId;
}

int Battle::getState() {
  return state;
}
//fight the enemies
int Battle::combat(Player user, Enemy enemy) {
  // if user chose fist, apply some damage from fist -> enemy
  // if user chose weapon, apply some damage from weapon -> enemy
  // then, analyze situation
  if (combatOver) {
    return endId;  // return whatever endId was at the end of the last call to combat()
  }
  int hitValue = 0;
  if (user.getHealth() <= 0) {
    hitValue = 0;
  }
  if (enemy.getHealth() <= 0) {
    hitValue = 3;
  }
  
  double userEnergy = user.getEnergy();
  double enemyEnergy = enemy.getEnergy();
  // apply player effect to enemy first, then enemy to player. then check results.
    if (userEnergy > enemyEnergy) {
        //cout <<"enemy hit!" << endl;
        hitValue = 1;
    } else if (enemyEnergy > userEnergy) {
        //cout << "You're hit!" << endl;
        hitValue = 2;
    } 
  //hitValue = max(hitValue, 3);
  //cout << "hitValue:" << hitValue <<endl;
  combatOver = true;

  return hitValue;
}

// Draw the dialog based on its current state
void Battle::render() {
  string decisionFull = "";
  switch (state) {
  case SILENCE:
    // do nothing, no conversation happening
    break;
  case GREETING:
    // Greeting mode; interpret the user's choice for the greeting
    mvprintw(TOP_OF_DIALOG_AREA, LEFT_OF_DIALOG_AREA, quoteBattleLine(attackString).c_str());
      decisionFull.append(fightBackString);
      mvprintw(TOP_OF_DIALOG_AREA + 1, LEFT_OF_DIALOG_AREA, decisionFull.c_str());
    break;
  case DECISION:

    erase();

    // Don't render decision after a while... even though we stay in the "decided" state until cleared by a user move
    //mvprintw(TOP_OF_DIALOG_AREA, LEFT_OF_DIALOG_AREA, to_string(endId).c_str());
    if (decisionTime > 0 && endId > -1) {
      decisionTime--;
      //cout << endId << ": " << combatOutcomeSets[endId] << endl;
      mvprintw(TOP_OF_DIALOG_AREA, LEFT_OF_DIALOG_AREA, quoteBattleLine(combatOutcomeSets[endId]).c_str());
    }

    break;
  }

}