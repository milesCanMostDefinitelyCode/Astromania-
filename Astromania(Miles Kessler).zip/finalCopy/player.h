#include <iostream>
#include <fstream>
#include <cstdlib> 
#include <vector>
#include <ncurses.h>
#include "mapPiece.h"
#include "weapon.h"
#ifndef PLAYER_H
#define PLAYER_H
#define DEFAULTMONEY 50
#define DEFAULTENERGY 50
#define DEFAULTHEALTH 150
#define DEFAULTSCORE 0
class Player {
    private:
        string username;
        double money;
        double energy;
        double health;
        double score;
        Weapon weapon;
    public:
        Player();
        Player(string inputName, string weaponName, int weaponType);
        int getUserKey();
        bool movementControl( vector<int>playerCoords, char userKey, int moveOffset[], vector<bool>availableMoves);
        string getUsername();
        double getMoney();
        double getEnergy();
        double getHealth();
        double getScore();
        Weapon getWeaponStats();
        void setWeaponStats(int weaponType);
        void createCustomWeapon(double newDamage, double newStrength, double newReach, string newName, string newType);
        void setUsername(string input);
        void addHealth(double newHealth);
        void setHealth(double endHealth);
        void addMoney(double newCash);
        void addEnergy(double newEG);
        void updateScore(double newScore);
};
#endif