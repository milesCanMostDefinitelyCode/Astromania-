#include <iostream>
#include <cmath>
#ifndef MAP_H
#define MAP_H
#include "mapPiece.h"
#include "weapon.h"
#include "enemy.h"
#include "battle.h"
#include "player.h"
#include "dialogue.h"
#define STARTTIME 0
#define LEVEL_ASTEROID 1
#define LEVEL_ENEMY 2
#define LEVEL_BAR 3
#define LEVEL_NEBULA 4


using namespace std;
class Map {
    private:
        int sideLength;
        vector<mapPiece> mapPieces;
        vector<string>levelTitles;
        vector<bool> findAvailableMapPositions(vector<int> currentPosition);
        bool findEmptyMapPosition(int openSpot[]);
        bool wonAsteroids;
        bool wonNebula;
        int deadEnemies;
        bool outcomeApplied;
        int levelType;
        bool leaveBar;
        Player player; // controller of the player's mapPiece (last mapPiece in the mapPiece vector)
        Enemy enemy[4];
        Dialog dialog;
        Battle battle;
        double inGameTime;
    public:
        Map(int level);
        int getSidelength();
        void showGameStatus(string userName,double health, double energy, string weapon, double score);
        int drawMap();
        Player getPlayerStats();
        void setupCurses();
        void shutdownCurses();
        bool updateMap();
        void fight(vector<mapPiece>mapPieces, char userKey);
        void consume();
        void converse(vector<mapPiece>mapPieces, char userKey);
};
#endif