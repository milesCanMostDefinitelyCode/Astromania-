#include <iostream>
#include <cmath>
#include <ncurses.h>
#include "map.h"
#include "mapPiece.h"
#include "asteroidSubClass.h"