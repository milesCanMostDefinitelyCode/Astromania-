#include <iostream>
#include <fstream>
#include <cstdlib> 
#include <vector>
#include <ncurses.h>
#include "mapPiece.h"
#ifndef BAR_H
#define BAR_H
#define NUM_BARPIECES 4

class Bar: public mapPiece {
    public:
        Bar(int posX, int posY) : mapPiece(ENEMY, posX, posY, 3) { 
        }
        

};
#endif