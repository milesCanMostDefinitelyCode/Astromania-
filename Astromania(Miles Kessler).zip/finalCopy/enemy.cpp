#include <iostream>
#include <cmath>
#include <ncurses.h>
#include "map.h"
#include "mapPiece.h"
#include "weapon.h"
#include "enemy.h"
using namespace std;
Enemy::Enemy() {
    health = 50;
    energy = 175;
    gangName = "Slice";
}
string Enemy::getGangName() {
    return gangName;
}
double Enemy::getHealth() {
    return health;
}
double Enemy::getEnergy() {
    return energy;
}
Weapon Enemy::getWeapon() {
    gangWeapon = Weapon();
    return gangWeapon;
}
void Enemy::updateHealth(double newH) {
    health = newH;
}
void Enemy::updateEnergy(double newE) {
    energy = newE;
}