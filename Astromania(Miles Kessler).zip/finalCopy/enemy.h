#include <iostream>
#include <fstream>
#include <cstdlib> 
#include <vector>
#include <ncurses.h>
#include "mapPiece.h"
#include "weapon.h"
#ifndef ENEMY_H
#define ENEMY_H
#define NUM_ENEMIES 4

class Enemy {
    private:
        double health;
        double energy;
        string memberName;
        Weapon gangWeapon;
        string gangName;
    public:
        Enemy();
        string getGangName();
        double getHealth();
        double getEnergy();
        void updateHealth(double newH);
        Weapon getWeapon();
        void updateEnergy(double newE);
};
#endif