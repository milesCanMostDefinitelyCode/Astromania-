#include <iostream>
#include <fstream>
#include "dialogue.h"
#include <ncurses.h>
#include <vector>
using namespace std;

Dialog::Dialog() {

  state = SILENCE;        // initially, no interaction going on
  conversationId = -1;    // initially, no conversation selected
  outcomeId = -1;         // once in a conversation, user sees some kind of outcome from a choice
  decisionTime = 0;       // how much time to display the results of a decision before dialog is cleared for a new conversation

  // Set up some interactions. You will read these from your files instead.

  // First conversation
  string line = "";
  ifstream greetingTxt;
  ifstream decisionTxt;
  ifstream decisionOutcomes;
  greetingTxt.open("dialogue/greetings.txt");
  decisionTxt.open("dialogue/answers.txt");
  decisionOutcomes.open("dialogue/decisionOutcomes.txt");
  while (!greetingTxt.eof()) {
    getline(greetingTxt, line);
    
    greetings.push_back(line);
  }
  greetingTxt.close();
  int decisionCount = 0;
  while (!decisionTxt.eof()) {
    for (int i = 0; i < 3; i++) {
        getline(decisionTxt, line);
        
        decisions[decisionCount].push_back(line);
    }
    decisionCount++;
  }
  decisionTxt.close();
  int outcomeCount = 0;
  while (!decisionOutcomes.eof()) {
    for (int i = 0; i < 3; i++) {
        getline(decisionOutcomes, line);
        //cout << line << endl;
        outcomeSets[outcomeCount].push_back(line);
    }
    outcomeCount++;
  }
  decisionOutcomes.close();

  
}

// what's a mapping table?  this maps elements in the dialog arrays back to mapPiece types
// int conversationMap[5][3];
// conversationMap[ENEMY] = {5};   // enemies can be assigned one of these 2 conversations
// conversationMap[NPC] = {1, 2, 3} ;  // NPC can be assigned one of these 3 conversations
// in mapPiece, assign a conversation id. 

// Code begins here


void Dialog::erase() {
  for (int i = 0; i < 5; ++i) {
    move(TOP_OF_DIALOG_AREA + i, LEFT_OF_DIALOG_AREA);
    clrtoeol();
  }
}

void Dialog::setState(int newState) {
  state = newState;
}

void Dialog::select(int whichConversation) {
  conversationId = whichConversation;
}

bool Dialog::canDialogStart() {
  return (state == SILENCE);
}

bool Dialog::inProgress() {
  return (state == GREETING || state == DECISION);
}

bool Dialog::completed() {
  return (state == DECISION);
}

void Dialog::start(int enemyID) {
  int newConversation = enemyID;
  select(newConversation); // select a random conversation
  setState(GREETING);      // change state to conversation is now in flight
}

void Dialog::end() {
  setState(SILENCE);
  erase();
}

string Dialog::quoteDialogLine (string dialogLine) {
  string quotedString = "";
  quotedString.append(dialogLine);
  return (quotedString);
}

void Dialog::decide(int newOutcomeId) {
  setState(DECISION);
  outcomeId = newOutcomeId;
  decisionTime = DIALOG_DECISION_DISPLAY_TIME;
}

int Dialog::interact(int userChar) {
  switch (state) {
  case SILENCE:
    // do nothing, no conversation happening
    break;
  case GREETING:
    // Greeting mode; interpret the user's choice for a decision, and set the outcome if a choice was provided by the user.
    switch (userChar) {
    case ASCII_KEY_1:
      decide(0);
      break;
    case ASCII_KEY_2:
      decide(1);
      break;
    case ASCII_KEY_3:
      decide(2);
      break;
    }
    break;
  case DECISION:
    // User made a decision. Possibly, do some other game logic here..
    break;
  }
  

  return 0;
}

// Draw the dialog based on its current state
void Dialog::render() {
  string decisionFull;
  switch (state) {
  case SILENCE:
    // do nothing, no conversation happening
    break;
  case GREETING:
    // Greeting mode; interpret the user's choice for the greeting
    //cout << "rendering" << endl;
    mvprintw(TOP_OF_DIALOG_AREA, LEFT_OF_DIALOG_AREA, quoteDialogLine(greetings[conversationId]).c_str());
    for (int i = 1; i < 4; ++i) {
      decisionFull = to_string(i);
      decisionFull.append(") ");
      decisionFull.append(decisions[conversationId][i-1]);
      mvprintw(TOP_OF_DIALOG_AREA + i + 1, LEFT_OF_DIALOG_AREA, decisionFull.c_str());
    }
    break;
  case DECISION:
    // Render user decision.
    erase();

    // Don't render decision after a while... even though we stay in the "decided" state until cleared by a user move
    if (decisionTime > 0) {
      decisionTime--;
      
      mvprintw(TOP_OF_DIALOG_AREA, LEFT_OF_DIALOG_AREA, quoteDialogLine(outcomeSets[conversationId][outcomeId]).c_str());
    }

    break;
  }

}
// int Battle::combat(Player user, Enemy enemy) {
//   if (user.getHealth() <= 0) {
//     return 0;
//   }
//   if (enemy.getHealth() <= 0) {
//     return 3;
//   }
//   int hitValue = 0;
//   if (enemy.getDamage() > user.getEnergy()) {
//       //cout << "You're hit!" << endl;
//       user.updateHealth(-enemy.getDamage());
//       user.updateEnergy(-enemy.getDamage());
//       hitValue++;
//   }
//   if (user.getDamage() > enemy.getEnergy()) {
//     //cout <<"enemy hit!" << endl;
//     enemy.updateHealth(-user.getDamage());
//     enemy.updateEnergy(-user.getDamage());
//     hitValue++;
//   }
//   return hitValue;
// }
//enemy data currently is a roadGang class that has all the enemy stats and a subclass of mapPiece
//would like to combine both into 1 separate class-enemy class
//call a int function here called Battle
//battle returns 4 ints
//1, player lost health
//2, player died
//3, enemy lost health
//4, enemy died
//when enemy dies, change enemy in question display character to X
//call battle as part of 2 part decision for enemy conversation:
//fight! main weapon or fist?
//fist is simply damage int, main weapon damage passed in thru a getter to weapon class
