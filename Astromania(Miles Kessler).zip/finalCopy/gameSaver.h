#include <iostream>
#include <fstream>
#include "Player.h"
#include "weapon.h"
#include "roadGang.h"
#include "map.h"
#include "Ogodei.h"
#ifndef GAMESAVER_H
#define GAMESAVER_H
using namespace std;
class gameSaver {
    private:
        weapon playerWeaponStats;
        int levelsComplete;
        bool Ogodei1Complete;
        bool NebulaComplete;
        bool Ogodei2Complete;
        Player PlayerStats;
    public:
        gameSaver();
        gameSaver(int levelNumber, Player CurrentPlayer, weapon currentWeapon, bool nebStat, bool Og1stat, bool Og2stat);
        bool getNebula();
        bool getOgodei1();
        bool getOgodei2();
        int getLevelsComplete();
        weapon getPlayerWeapon();
        Player getPlayer();
        void updateOgodei1(bool OgoComplete);
        void updateOgodei2(bool Ogo2Complete);
        void updateNebula(bool NebComplete);
        void updateLevel(int levelCount);
};
#endif