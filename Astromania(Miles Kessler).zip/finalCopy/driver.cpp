#include <iostream>
#include <ncurses.h>
#include <time.h>
#include "map.h"
#include "mapPiece.h"
#include "player.h"
#include "enemy.h"
#include "dialogue.h"
#include "battle.h"
using namespace std;
void imagePrint(string txtName) {
    ifstream imageTxt;
    string line = "";
    int lineCounter = 0;
    imageTxt.open(txtName);
    for (int i = 35; i < 74; i++) {
        getline(imageTxt,line);
        if (line.length() > 1) {
            cout << line << endl;
        }
    }
}
bool ogodeiLevel(Map playerStatsSource) {
    bool victory = false;
    bool complete = false;
    imagePrint("images/OgodeiImage.txt");
    cout << endl;
    string trustChoice;
    int intTrustChoice;
    cout << "You pick up a mysterious figure. He identifies himself as Ogodei," << endl;
    cout << "a drifter. 'once with great power to my name...'" << endl;
    cout << "He says, 'I have an important place to be but I must pilot your ship myself to make it there.'" << endl;
    cout << "You ask why he must fly the ship. He replies 'No one can know the exact location but me.'" << endl;
    cout << "Do you trust him?" << endl;
    cout << "1) yes  2) no" << endl;
    getline(cin, trustChoice);
    sscanf(trustChoice.c_str(), "%d", &intTrustChoice);
    while (!complete) {
        switch(intTrustChoice) {
            case 1:
                playerStatsSource.getPlayerStats().setHealth(0);
                complete = true;
                break;
            case 2:
                victory = true;
                complete = true;
                break;
            default:
                cout << "please re-enter your choice." << endl;
                break;
        }  
    } 
    return victory;  
}
int main() {
    srand(time(NULL));
    Map maps[4] = { Map(LEVEL_ASTEROID), Map(LEVEL_ENEMY), Map(LEVEL_BAR), Map(LEVEL_NEBULA)};
    bool exitedLevel;
    char resp;
    bool finishedGame = false;
    bool gameInProgress = true;
    int playerLevel = 0;
    int gameChoice = 1;
    int levelChoice;
    int levelOutcome = 0;
    int endgame;
    //maps[playerLevel].setupCurses();
    //maps[playerLevel].shutdownCurses();
    //maps[0] is the easiest map with simple enemies and asteroids
    switch(gameChoice) {
        case 1:
            maps[playerLevel].setupCurses();
            while(gameInProgress) {
                exitedLevel = false;
                while (!exitedLevel) {
                    levelOutcome = maps[playerLevel].drawMap();
                    if (levelOutcome == 2 || levelOutcome == 1) {
                        //player died or map broke or quit 
                        exitedLevel = true;
                        gameInProgress = false;
                        
                    } else if (levelOutcome == 3) {
                        endgame = levelOutcome - 3;
                        playerLevel++;
                        cout <<  "we're on level" << playerLevel << endl;
                        exitedLevel = true;
                    } else {
                        //brings into ogodei level
                        if (levelOutcome != 0) {
                            endgame = levelOutcome -3;
                            exitedLevel = true;
                            gameInProgress = false;
                            
                        }
                        
                    }
                    
                }
                
            }
            maps[playerLevel].shutdownCurses();  
            if (endgame == 1 && levelOutcome > 2) {
                //endwin();
                // cout << "line1" << endl;
                // cout << "line2" << endl;

                finishedGame = ogodeiLevel(maps[3]);
                if (finishedGame == true) {
                    cout << "You win!" << endl;
                }
            } else {
                break;
            }
            break;
            case 2: 
                break;
    }
    

}
//new game
//switch statement of each game loop-levels
//break only if player is dead
//otherwise fall through from case to case until last level
//same for resume saved but you start based on level choice
//same switch for individual levels but with breaks so u only play one at a time