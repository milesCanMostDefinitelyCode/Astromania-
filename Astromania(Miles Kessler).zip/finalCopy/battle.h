#include <iostream>
#include <string>
#include <vector>
#include "player.h"
//#include "roadGang.h"
#ifndef BATTLE_H
#define BATTLE_H
#define SILENCE 0 // no dialog happening
#define GREETING 1
#define DECISION 2

#define ASCII_KEY_1 49
#define ASCII_KEY_2 50
#define ASCII_KEY_3 51
#define LEFT_OF_DIALOG_AREA 20
#define TOP_OF_DIALOG_AREA 2
#define DIALOG_DECISION_DISPLAY_TIME 30 // 3 seconds (each loop is 1/10th of a second) for decision display to clear

#define USER_DECISION_WEAPON 0
#define USER_DECISION_FIST 1
#define USER_FIST_DAMAGE 20

using namespace std;
class Battle  {
 private:
    int fightingId;
    int outcomeId;
    int state;
    int endId;
    int decisionTime;
    bool combatOver;
    string attackString;
    string fightBackString;   // up to 2 decisions for every prompt-same every enemy-fight with fist or weapon
    vector<string> combatOutcomeSets; // 4 outcomes for every decision- you die, they die, you get hurt, they get hurt 
    string quoteBattleLine(string battleLine);
 public:
    Battle();
    void start(int enemyID);
    void end();
    void decide(int outcomeId);
    void setState(int newState);
    void select(int whichConversation);
    bool canBattleStart();
    bool inProgress();
    bool completed();
    int getEndId();
    int getState();
    int combat(Player user, Enemy enemy);
    int  interact(int userChar, Player user, Enemy gangMember);
    void render();
    void erase();
};
#endif