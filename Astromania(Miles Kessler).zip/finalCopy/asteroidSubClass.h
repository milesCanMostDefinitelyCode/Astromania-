#include <iostream>
#include <fstream>
#include <cstdlib> 
#include <vector>
#include <ncurses.h>
#include "mapPiece.h"
#ifndef ASTEROID_H
#define ASTEROID_H
#define NUM_ASTEROIDS 8

class Asteroid: public mapPiece {
    public:
        Asteroid(int posX, int posY) : mapPiece(ENEMY, posX, posY, -1) { 
        }
};
#endif