// The pplayer is a controller for the player's mapPiece.
// It receives  a player mapPiece,  gets user input, and applies logic to decide how to move the player's piece.
// it's like a "robot arm" for the player's mapPiece


#include <iostream>
#include <fstream>
#include <cstdlib> 
#include <vector>
#include <stdio.h>
#include <ncurses.h>
#include "mapPiece.h"
#include "player.h"
#include "weapon.h"
using namespace std;
Player::Player() {
    username = "default";
    money = DEFAULTMONEY;
    energy = DEFAULTENERGY;
    health = DEFAULTHEALTH;
    score = DEFAULTSCORE;
}

Player::Player(string inputName, string weaponName, int weaponType) {
    username = inputName;
    money = DEFAULTMONEY;
    energy = DEFAULTENERGY;
    health = DEFAULTHEALTH;
    score = DEFAULTSCORE;
    weapon = Weapon(weaponType);
    weapon.setWeaponName(weaponName);

}

int Player::getUserKey() {
    int ch;
    ch = getch();
    return ch;
}

bool Player::movementControl( vector<int>playerCoords, char userKey, int moveOffset[], vector<bool>availableMoves) {
    int moveIndex;
    string userName;
    char weaponTypeKey;
    Player userPick = Player();
    switch(userKey) {
            case 119: // w
                moveIndex = 3;

                if (availableMoves[moveIndex] == 1) {
                    //cout << "trynna moved up:" << availableMoves[moveIndex] <<endl;
                    moveOffset[0] = -1;
                    moveOffset[1] = 0;
                    //playerMapPiece->move(-1, 0);
                    // mvprintw(11, 11, "player newPosition: ");
                    // mvprintw(12, 11, to_string(playerPosition[1]).c_str());
                }
                break;
            case 115: // s
                moveIndex = 1;
               if (availableMoves[moveIndex] == true) {
                    moveOffset[0] = 1;
                    moveOffset[1] = 0;
                }
                break;
            case 97: // a
                moveIndex = 0;
                if (availableMoves[moveIndex] == true) {
                    moveOffset[0] = 0;
                    moveOffset[1] = -1;
                }
                break;
            case 100: // d
                moveIndex = 2;
                if (availableMoves[moveIndex] == true) {
                    moveOffset[0] = 0;
                    moveOffset[1] = 1;
                }
                break;
            case 27: // esc/quit the game instantly
                return false;
                break;
            case 117: // u key
                userPick.setUsername(userName);
                break;
            case 112: // p key, pick your weapon
                switch(weaponTypeKey) {
                    case 1:
                        userPick.setWeaponStats(1);
                        break;
                    case 2:
                        userPick.setWeaponStats(2);
                        break;
                    case 3: 
                        userPick.setWeaponStats(3);
                        break;
                }
                
                break;
        }
    return true;
}
string Player::getUsername() {
    return username;
}
double Player::getMoney() {
    return money;
}
double Player::getEnergy() {
    return energy;
}
double Player::getHealth() {
    return health;
}
double Player::getScore() {
    return score;
}
void Player::setUsername(string input) {
    username = input;
}
Weapon Player::getWeaponStats() {
    return weapon;
}
void Player::setWeaponStats(int weaponType) {
    weapon = Weapon(weaponType);
}
void Player::createCustomWeapon(double newDamage, double newStrength, double newReach, string newName, string newType) {
    weapon = Weapon(newDamage, newStrength, newReach, newName, newType);
}
void Player::addHealth(double newHealth) {
    health += newHealth;
}
void Player::setHealth(double endHealth) {
    health = endHealth;
}
void Player::addMoney(double newCash) {
    money += newCash;
}
void Player::addEnergy(double newEG) {
    energy += newEG;
}
void Player::updateScore(double newScore) {
    score = newScore;
}
//create a Player with money, energy, a name, and a weapon object
// Player Player::setWeaponStats(string weaponName, string WeaponType) {
//     Player weapon = Player
// }

// 