#include <iostream>
#include <fstream>
#include <cstdlib> 
#include <vector>
#include <ncurses.h>
#include "mapPiece.h"
#ifndef NPC_H
#define NPC_H
#define NUM_NPCS 3

class Npc: public mapPiece {
    public:
        Npc(int posX, int posY) : mapPiece(ENEMY, posX, posY, 0) { 
        }
        

};
#endif