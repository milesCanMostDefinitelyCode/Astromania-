//if else statements for dialogue with Ogodei character
//ogodei NPC created thru dialogue-no player object
#include <iostream>
#include "Ogodei.h"
using namespace std;
Ogodei::Ogodei() {
    dialogueCounter = 0;
    firstLevel = false;
    secondLevel = false;
}
Ogodei::Ogodei(int leveltype, int dialogue) {
    if (dialogue > 0) {
        firstLevel = true;
        dialogueCounter = dialogue;
    }
    if (leveltype == 2) {
        secondLevel = true;
    }

}
bool Ogodei::getFirstLevel () {
    return firstLevel;
}
bool Ogodei::getSecondLevel() {
    return secondLevel;
}
void Ogodei::setFirstLevel(bool firstLevel, int dialogue) {
    if (firstLevel == true || dialogue > 0) {
        firstLevel = true;
    }
}
void Ogodei::setSecondLevel(bool secondLevel) {
    if (secondLevel == true) {
        secondLevel = true;
    }
}