#include <iostream>
#ifndef OGODEI_H
#define OGODEI_H
using namespace std;
class Ogodei {
    private:
        bool firstLevel;
        bool secondLevel;
        int dialogueCounter;

    public:
      Ogodei();
      Ogodei(int leveltype, int dialogue);
      bool getFirstLevel();
      bool getSecondLevel();
      void setFirstLevel(bool firstLevel, int dialogue);
      void setSecondLevel(bool secondLevel);
};
#endif