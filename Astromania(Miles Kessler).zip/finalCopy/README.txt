------------------------
HOW TO COMPILE AND RUN
------------------------
Compile: ++ -o driver driver.cpp mapPiece.cpp map.cpp enemy.cpp NPCSubClass.cpp asteroidSubClass.cpp barSubClass.cpp  player.cpp weapon.cpp dialogue.cpp battle.cpp -lncurses -std=c++11
Run: ./driver
------------------------
DEPENDENCIES
------------------------
all classes and subclasses(they're labeled) must be in 1 folder to compile properly. 
Ensure to enter correct characters in conversations and fights.
------------------------
SUBMISSION INFORMATION
------------------------
CSCI1300 Fall 2022 Project 3
Author: Miles Kessler
Recitation: 306 - Zach Adkins
Date: Dec 1, 2022
------------------------
ABOUT THIS PROJECT
------------------------
This is the most advanced Role-playing game I can make in 4 weeks. This game has 5 levels:
4 map levels of varying sizes, and one decision-based level. Each map level is its own map 
with its own set of pieces. Player movement and stat display is consistent throughout the map
levels. Difficulty and player customization packs are available for 350 galactic yeds(game money).
Your health is short and depletes fast--watch it.