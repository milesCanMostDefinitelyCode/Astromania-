#include <iostream>
#include <fstream>
#include <cstdlib> 
#include <vector>
#include <ncurses.h>
#include "map.h"
#ifndef MAPPIECE_H
#define MAPPIECE_H
#define PLAYER 0
#define NPC 1
#define ENEMY 2
#define BAR 3
#define ASTEROID 4
#define NEBULA 5
#define ENERGY_PACK 6
#define HEALTH_PACK 7
#define NUM_ENERGY_PACKS 3
#define NUM_HEALTH_PACKS 3
#define HEALTH_PACK_TRANSFER_SPEED 50
#define ENERGY_PACK_TRANSFER_SPEED 50
using namespace std;
class mapPiece {
    private:
        int pieceType;
        int healthPackAmount;
        int energyPackAmount;
        vector<int>position;
        string displayCharacters[8];
        int conversationID;
        int assignableConversations[8][3] = { {1}, {0, 1, 2}, {4}, {3}, {1}, {1}, {1}, {1} };
    public:
        mapPiece();
        mapPiece(int type, int posX, int posY, int conversationId);
        int getPieceType();
        int getConversationId();
        vector<int> getPosition();
        bool setPosition(int posX, int posY);
        string getDisplayCharacter();
        int getHealthPackAmount();
        int getEnergyPackAmount();
        void depleteEnergy(int depleteAmount);
        void depleteHealth(int depleteAmount);
        void randomMove(vector<bool> availableDirections, int mapWidth);
        void move(int deltaX, int deltaY, int mapWidth);
};

#endif