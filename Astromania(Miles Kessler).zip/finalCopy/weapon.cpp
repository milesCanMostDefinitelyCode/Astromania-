#include <iostream>
#include <cmath>
#include "weapon.h"
using namespace std;
Weapon::Weapon() {
    damage = BASICDAM;
    strength = BASICSTRENGTH;
    reach = BASICREACH;
    weaponName = "Basic Pistol";
}
Weapon::Weapon(int type) {
    if (type < 1 || type > 3) {
        switch(type) {
            case 1:
                strength = MELEESTRENGTH;
                damage = MELEEDAM;
                reach = MELEEREACH;
                weaponName = "Basic Machete";
                weaponType = "Knife";
            case 2:
                strength = PISTOLSTRENGTH;
                reach = PISTOLREACH;
                damage = PISTOLDAM;
                weaponName = "Basic Pistol";
                weaponType = "Pistol";
            case 3:
                strength = LONGGUNSTRENGTH;
                reach = LONGGUNREACH;
                damage = LONGGUNDAM;
                weaponName = "Basic Longarm";
                weaponType = "Long Gun";
        }
    }
    else {
        cout << "Invalid input" << endl;
    }
}
Weapon::Weapon(double newDamage, double newStrength, double newReach, string newName, string newType) {
    damage = newDamage;
    strength = newStrength;
    reach = newReach;
    weaponName = newName;
    weaponType = newType;
}
double Weapon::getDamage() {
    return damage;
}
double Weapon::getStrength() {
    return strength;
}
double Weapon::getReach() {
    return reach;
}
string Weapon::getWeaponName() {
    return weaponName;
}
string Weapon::getWeaponType() {
    return weaponType;
}
void Weapon::setDamage(double newDamage) {
    damage = newDamage;
}
void Weapon::setStrength(double newStrength) {
    strength = newStrength;
}
void Weapon::setReach(double newReach) {
    reach = newReach;
}
void Weapon::setWeaponName(string newWeaponName) {
    weaponName = newWeaponName;
}
void Weapon::setWeaponType(string diffType) {
    weaponType = diffType;
}